# Dance-Academy-Website
This repository contains the source code for the RD Dance Academy website, a website designed to manage student registrations and know about academy and can contact. It includes Student registration page, About page, Contact Page, and manage students which can be accessed only by the admin called as Authentication
